//
//  HPAppPulse.h
//  RUMService
//
//  Copyright (c) 2015 HP. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//for backwards compatability
#define HPUserMonitoringSDK HPAppPulse
#define HPAppPulseInstance [HPAppPulse sharedInstance]
@interface HPAppPulseCrashReport: NSObject
@property (strong, nonatomic) NSString* crashName;
@property (strong, nonatomic) NSString* crashType;
@property (strong, nonatomic) NSString* crashReason;
@property (strong, nonatomic) NSArray* stackTraceInfo; // Stack trace information ...

@end

@class HPAppPulse;
@protocol HPUserMonitoringSDKDelegate <NSObject>
@required
- (void) hpAppPulseDidDetectException: (HPAppPulseCrashReport *) crashReport;
@end

@interface HPAppPulse : NSObject
@property (nonatomic, weak) id <HPUserMonitoringSDKDelegate> delegate;
+ (BOOL) getOptStatus;
+ (void) setOptStatus: (BOOL) status;
+ (HPAppPulse *)sharedInstance;

typedef enum HPControlType{
    HPButtonControl,
    HPTabControl,
    HPSwitchControl,
    HPStepperControl,
    HPSliderControl,
    HPSearchBarControl,
    HPNavigationBarControl,
    HPListItemControl,
    HPCollectionViewControl
} HPControlType;

+ (void) setScreenName:(UIViewController*)vc screenName:(NSString*)name;
+ (void) setControlName:(UIView*)control controlName:(NSString*)controlName;
+ (void) setControlName:(UIView*)control controlName:(NSString*)controlName withScreenName:(NSString*)screenName;
//#ifdef AppPulseMobile
+ (void) setControlType:(UIView*)control controlType:(HPControlType)type;
//#endif
+ (void) addBreadcrumb:(NSString *)text;
+ (void) reportCrash: (NSException*) exception;
+ (void) reportCrashWithError: (NSError*) error;
+ (void) reportHandledException:(NSException *)exception withDescription:(NSString *)description;
+ (void) reportHandledException:(NSException *)exception;
+ (void) reportError:(NSError*)error withDescription:(NSString *)description;
+ (void) reportError:(NSError*)error;
+ (void) enableCrashReportModule;
@end
